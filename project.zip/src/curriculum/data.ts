import { RAW_COURSES, type RawCourse } from './rawData';

export type CourseTag = 'required' | 'elective' | 'recommended';

export type Semester = 'F1' | 'S1' | 'F2' | 'S2' | 'F3' | 'S3' | 'F4' | 'S4';

export interface Specialty {
  key: string;
  name: string;
  type: 'first' | 'second';
  typeName: string;
}

export interface Course {
  id: string;
  name: string;
  specialtyKey: string;
  specialtyName: string;
  tag: CourseTag;
  credits: number;
  semester: Semester;
  prereqs: string[];
}

export const SEMESTERS: { id: Semester; label: string }[] = [
  { id: 'F1', label: '大一上' },
  { id: 'S1', label: '大一下' },
  { id: 'F2', label: '大二上' },
  { id: 'S2', label: '大二下' },
  { id: 'F3', label: '大三上' },
  { id: 'S3', label: '大三下' },
  { id: 'F4', label: '大四上' },
  { id: 'S4', label: '大四下' },
];

const SEMESTER_MAP: Record<string, Semester> = {
  '1-1': 'F1', '1-2': 'S1',
  '2-1': 'F2', '2-2': 'S2',
  '3-1': 'F3', '3-2': 'S3',
  '4-1': 'F4', '4-2': 'S4',
};

const TAG_MAP: Record<string, CourseTag> = {
  '必修': 'required',
  '選修': 'elective',
  '建議先修': 'recommended',
};

export const TAG_META: Record<CourseTag, { label: string; className: string }> = {
  required: { label: '必修', className: 'bg-red-100 text-red-700 border-red-200' },
  elective: { label: '選修', className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  recommended: { label: '建議', className: 'bg-amber-100 text-amber-700 border-amber-200' },
};

// Color palette for specialties - first specialty gets blue/yellow tones, second gets orange/green tones
// Extended palette for many specialties
const FIRST_SPEC_COLORS = [
  { card: 'bg-blue-50', border: 'border-blue-300', glow: 'shadow-blue-400/50', accent: 'text-blue-700' },
  { card: 'bg-yellow-50', border: 'border-yellow-300', glow: 'shadow-yellow-400/50', accent: 'text-yellow-700' },
  { card: 'bg-cyan-50', border: 'border-cyan-300', glow: 'shadow-cyan-400/50', accent: 'text-cyan-700' },
  { card: 'bg-sky-50', border: 'border-sky-300', glow: 'shadow-sky-400/50', accent: 'text-sky-700' },
];

const SECOND_SPEC_COLORS = [
  { card: 'bg-orange-50', border: 'border-orange-300', glow: 'shadow-orange-400/50', accent: 'text-orange-700' },
  { card: 'bg-green-50', border: 'border-green-300', glow: 'shadow-green-400/50', accent: 'text-green-700' },
  { card: 'bg-teal-50', border: 'border-teal-300', glow: 'shadow-teal-400/50', accent: 'text-teal-700' },
  { card: 'bg-lime-50', border: 'border-lime-300', glow: 'shadow-lime-400/50', accent: 'text-lime-700' },
  { card: 'bg-emerald-50', border: 'border-emerald-300', glow: 'shadow-emerald-400/50', accent: 'text-emerald-700' },
  { card: 'bg-amber-50', border: 'border-amber-300', glow: 'shadow-amber-400/50', accent: 'text-amber-700' },
  { card: 'bg-rose-50', border: 'border-rose-300', glow: 'shadow-rose-400/50', accent: 'text-rose-700' },
  { card: 'bg-fuchsia-50', border: 'border-fuchsia-300', glow: 'shadow-fuchsia-400/50', accent: 'text-fuchsia-700' },
  { card: 'bg-pink-50', border: 'border-pink-300', glow: 'shadow-pink-400/50', accent: 'text-pink-700' },
  { card: 'bg-stone-50', border: 'border-stone-300', glow: 'shadow-stone-400/50', accent: 'text-stone-700' },
  { card: 'bg-indigo-50', border: 'border-indigo-300', glow: 'shadow-indigo-400/50', accent: 'text-indigo-700' },
  { card: 'bg-violet-50', border: 'border-violet-300', glow: 'shadow-violet-400/50', accent: 'text-violet-700' },
  { card: 'bg-purple-50', border: 'border-purple-300', glow: 'shadow-purple-400/50', accent: 'text-purple-700' },
  { card: 'bg-slate-50', border: 'border-slate-300', glow: 'shadow-slate-400/50', accent: 'text-slate-700' },
  { card: 'bg-red-50', border: 'border-red-300', glow: 'shadow-red-400/50', accent: 'text-red-700' },
  { card: 'bg-warm-50', border: 'border-orange-300', glow: 'shadow-orange-400/50', accent: 'text-orange-700' },
  { card: 'bg-lime-50', border: 'border-lime-300', glow: 'shadow-lime-400/50', accent: 'text-lime-700' },
  { card: 'bg-teal-50', border: 'border-teal-300', glow: 'shadow-teal-400/50', accent: 'text-teal-700' },
];

// Process raw data into structured courses
function processData() {
  const specialties: Specialty[] = [];
  const specialtyMap = new Map<string, Specialty>();
  const courses: Course[] = [];

  // Group raw courses by (specialty, specialtyType)
  const groups = new Map<string, RawCourse[]>();
  for (const rc of RAW_COURSES) {
    const type: 'first' | 'second' = rc.specialtyType === '一專' ? 'first' : 'second';
    const key = `${rc.specialty}__${type}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(rc);
  }

  let firstIdx = 0;
  let secondIdx = 0;

  for (const [key, raws] of groups) {
    const [name, typeStr] = key.split('__');
    const type = typeStr as 'first' | 'second';
    const specKey = `${type === 'first' ? 'f' : 's'}-${firstIdxOrSecondIdx(type, type === 'first' ? firstIdx : secondIdx)}`;

    const spec: Specialty = {
      key: specKey,
      name,
      type,
      typeName: type === 'first' ? '一專' : '二專',
    };
    specialties.push(spec);
    specialtyMap.set(key, spec);

    if (type === 'first') firstIdx++;
    else secondIdx++;

    // Build name-to-id map within this specialty group
    const nameToId = new Map<string, string>();
    raws.forEach((rc, i) => {
      const id = `${specKey}-${i}`;
      nameToId.set(rc.name, id);
    });

    // Create courses with resolved prereq IDs
    raws.forEach((rc, i) => {
      const id = `${specKey}-${i}`;
      const prereqIds = rc.suggestedPrerequisites
        .map((pname) => nameToId.get(pname))
        .filter((pid): pid is string => pid !== undefined);

      courses.push({
        id,
        name: rc.name,
        specialtyKey: specKey,
        specialtyName: name,
        tag: TAG_MAP[rc.type] ?? 'elective',
        credits: rc.credits,
        semester: SEMESTER_MAP[rc.semester] ?? 'F1',
        prereqs: prereqIds,
      });
    });
  }

  return { specialties, courses };
}

function firstIdxOrSecondIdx(_type: 'first' | 'second', idx: number): number {
  return idx;
}

const { specialties: ALL_SPECIALTIES, courses: ALL_COURSES } = processData();

export const SPECIALTIES = ALL_SPECIALTIES;
export const COURSES = ALL_COURSES;

export const FIRST_SPECIALTY_OPTIONS = ALL_SPECIALTIES.filter((s) => s.type === 'first');
export const SECOND_SPECIALTY_OPTIONS = ALL_SPECIALTIES.filter((s) => s.type === 'second');

export const DEFAULT_FIRST: string = FIRST_SPECIALTY_OPTIONS.find((s) => s.name === '計量財務金融')?.key ?? FIRST_SPECIALTY_OPTIONS[0].key;
export const DEFAULT_SECOND: string = SECOND_SPECIALTY_OPTIONS.find((s) => s.name === '資訊工程')?.key ?? SECOND_SPECIALTY_OPTIONS[0].key;

export function getSpecialtyByKey(key: string): Specialty | undefined {
  return ALL_SPECIALTIES.find((s) => s.key === key);
}

export function getCoursesForSpecialties(keys: string[]): Course[] {
  return ALL_COURSES.filter((c) => keys.includes(c.specialtyKey));
}

export function getSpecialtyColor(specialtyKey: string, isFirst: boolean): { card: string; border: string; glow: string; accent: string } {
  if (isFirst) {
    const idx = FIRST_SPECIALTY_OPTIONS.findIndex((s) => s.key === specialtyKey);
    return FIRST_SPEC_COLORS[idx % FIRST_SPEC_COLORS.length];
  } else {
    const idx = SECOND_SPECIALTY_OPTIONS.findIndex((s) => s.key === specialtyKey);
    return SECOND_SPEC_COLORS[idx % SECOND_SPEC_COLORS.length];
  }
}

export function getSpecialtyColors(keys: string[]): Record<string, { card: string; border: string; glow: string; accent: string }> {
  const result: Record<string, { card: string; border: string; glow: string; accent: string }> = {};
  for (const key of keys) {
    const spec = getSpecialtyByKey(key);
    if (spec) {
      result[key] = getSpecialtyColor(key, spec.type === 'first');
    }
  }
  return result;
}

import { useState } from 'react';
import { Map, Sparkles, ChevronDown } from 'lucide-react';
import {
  FIRST_SPECIALTY_OPTIONS,
  SECOND_SPECIALTY_OPTIONS,
  getSpecialtyByKey,
  type Specialty,
} from '../curriculum/data';

interface NavbarProps {
  specOne: string;
  specTwo: string;
  onSpecOneChange: (key: string) => void;
  onSpecTwoChange: (key: string) => void;
  onGenerate: () => void;
}

const ACCENT_MAP: Record<'blue' | 'orange', { dot: string; ring: string }> = {
  blue: { dot: 'bg-blue-500', ring: 'focus:ring-blue-400' },
  orange: { dot: 'bg-orange-500', ring: 'focus:ring-orange-400' },
};

function SpecialtySelect({
  label,
  value,
  options,
  accent,
  onChange,
}: {
  label: string;
  value: string;
  options: Specialty[];
  accent: 'blue' | 'orange';
  onChange: (key: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const a = ACCENT_MAP[accent];
  const selected = getSpecialtyByKey(value);
  return (
    <div className="relative">
      <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wider text-slate-400">
        {label}
      </label>
      <button
        onClick={() => setOpen((o) => !o)}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        className={`flex min-w-[150px] items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-all hover:border-slate-300 hover:shadow-md focus:outline-none focus:ring-2 ${a.ring}`}
      >
        <span className={`h-2.5 w-2.5 rounded-full ${a.dot}`} />
        <span className="flex-1 text-left">{selected?.name ?? '—'}</span>
        <ChevronDown className={`h-4 w-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="absolute z-50 mt-1 max-h-72 w-full animate-[fadeIn_0.15s_ease-out] overflow-y-auto rounded-xl border border-slate-200 bg-white py-1 shadow-xl">
          {options.map((opt) => (
            <button
              key={opt.key}
              onClick={() => {
                onChange(opt.key);
                setOpen(false);
              }}
              className={`flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition-colors hover:bg-slate-50 ${
                opt.key === value ? 'bg-slate-50 font-semibold text-slate-900' : 'text-slate-600'
              }`}
            >
              <span className={`h-2.5 w-2.5 rounded-full ${a.dot}`} />
              {opt.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Navbar({
  specOne,
  specTwo,
  onSpecOneChange,
  onSpecTwoChange,
  onGenerate,
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-4 px-6 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-orange-500 text-white shadow-md">
            <Map className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-base font-bold leading-tight text-slate-900">
              雙專長課程地圖生成器
            </h1>
            <p className="text-[11px] text-slate-400">Interactive Double-Specialty Curriculum Map</p>
          </div>
        </div>

        <div className="flex flex-wrap items-end gap-3">
          <SpecialtySelect
            label="專長一"
            value={specOne}
            options={FIRST_SPECIALTY_OPTIONS}
            accent="blue"
            onChange={onSpecOneChange}
          />
          <div className="pb-2 text-lg font-light text-slate-300">+</div>
          <SpecialtySelect
            label="專長二"
            value={specTwo}
            options={SECOND_SPECIALTY_OPTIONS}
            accent="orange"
            onChange={onSpecTwoChange}
          />
        </div>

        <button
          onClick={onGenerate}
          className="ml-auto flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition-all hover:bg-slate-800 hover:shadow-lg active:scale-95"
        >
          <Sparkles className="h-4 w-4" />
          生成合併地圖
        </button>
      </div>
    </header>
  );
}

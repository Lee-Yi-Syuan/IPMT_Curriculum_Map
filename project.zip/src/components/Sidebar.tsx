import { CheckCircle2, Circle, BookOpen, Layers, TrendingUp } from 'lucide-react';
import {
  getSpecialtyByKey,
  TAG_META,
  type Course,
} from '../curriculum/data';

interface SidebarProps {
  courses: Course[];
  specOneKey: string;
  specTwoKey: string;
  activeCourse: Course | null;
}

export default function Sidebar({ courses, specOneKey, specTwoKey, activeCourse }: SidebarProps) {
  const requiredCourses = courses.filter((c) => c.tag === 'required');
  const totalRequiredCredits = requiredCourses.reduce((s, c) => s + c.credits, 0);
  const totalCredits = courses.reduce((s, c) => s + c.credits, 0);

  const specOne = getSpecialtyByKey(specOneKey);
  const specTwo = getSpecialtyByKey(specTwoKey);

  const bySpec = (key: string) => courses.filter((c) => c.specialtyKey === key);
  const specOneRequired = bySpec(specOneKey).filter((c) => c.tag === 'required');
  const specTwoRequired = bySpec(specTwoKey).filter((c) => c.tag === 'required');

  const checklist = [
    { label: `${specOne?.name ?? ''} 必修`, count: specOneRequired.length, total: bySpec(specOneKey).length },
    { label: `${specTwo?.name ?? ''} 必修`, count: specTwoRequired.length, total: bySpec(specTwoKey).length },
    { label: '跨域選修', count: courses.filter((c) => c.tag === 'elective').length, total: courses.length },
    { label: '建議先修', count: courses.filter((c) => c.tag === 'recommended').length, total: courses.length },
  ];

  return (
    <aside className="flex w-full flex-col gap-4 lg:w-72">
      {/* Active course detail */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-700">
          <BookOpen className="h-4 w-4 text-slate-400" />
          課程資訊
        </h3>
        {activeCourse ? (
          <div className="animate-[fadeIn_0.2s_ease-out]">
            <p className="text-base font-bold text-slate-900">{activeCourse.name}</p>
            <div className="mt-2 flex items-center gap-2">
              <span className={`rounded border px-2 py-0.5 text-[11px] font-semibold ${TAG_META[activeCourse.tag].className}`}>
                {TAG_META[activeCourse.tag].label}
              </span>
              <span className="text-xs text-slate-500">{activeCourse.credits} 學分</span>
            </div>
            <div className="mt-3 border-t border-slate-100 pt-3">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">建議先修</p>
              {activeCourse.prereqs.length > 0 ? (
                <ul className="mt-1 space-y-1">
                  {activeCourse.prereqs.map((pid) => {
                    const pre = courses.find((c) => c.id === pid);
                    return pre ? (
                      <li key={pid} className="flex items-center gap-1.5 text-xs text-slate-600">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                        {pre.name}
                      </li>
                    ) : null;
                  })}
                </ul>
              ) : (
                <p className="mt-1 text-xs text-slate-400">無建議先修課程</p>
              )}
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-400">點擊或懸停任一課程卡片查看詳細資訊與建議先修關係</p>
        )}
      </div>

      {/* Credit summary */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-700">
          <Layers className="h-4 w-4 text-slate-400" />
          學分統計
        </h3>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-slate-50 p-3">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">必修學分</p>
            <p className="mt-1 text-2xl font-bold text-slate-900">{totalRequiredCredits}</p>
          </div>
          <div className="rounded-xl bg-slate-50 p-3">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">總學分</p>
            <p className="mt-1 text-2xl font-bold text-slate-900">{totalCredits}</p>
          </div>
        </div>
      </div>

      {/* Checklist */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-700">
          <TrendingUp className="h-4 w-4 text-slate-400" />
          學分查核清單
        </h3>
        <ul className="space-y-2.5">
          {checklist.map((item) => (
            <li key={item.label} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {item.count > 0 ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                ) : (
                  <Circle className="h-4 w-4 text-slate-300" />
                )}
                <span className="text-xs font-medium text-slate-600">{item.label}</span>
              </div>
              <span className="text-xs font-semibold text-slate-400">
                {item.count} / {item.total}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}

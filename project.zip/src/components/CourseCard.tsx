import { GraduationCap } from 'lucide-react';
import {
  TAG_META,
  type Course,
} from '../curriculum/data';

export type HighlightState = 'active' | 'prereq' | 'dependent' | 'dim' | 'none';

interface CourseCardProps {
  course: Course;
  highlight: HighlightState;
  prereqNames: string[];
  onHover: (id: string | null) => void;
  onClick: (id: string) => void;
  registerRef: (id: string, el: HTMLDivElement | null) => void;
  colors: { card: string; border: string; glow: string; accent: string };
}

const HIGHLIGHT_STYLES: Record<HighlightState, string> = {
  active: 'ring-2 ring-slate-900 scale-[1.03] shadow-xl z-20 brightness-105',
  prereq: 'ring-2 ring-emerald-500 shadow-lg z-10',
  dependent: 'ring-2 ring-violet-500 shadow-lg z-10',
  dim: 'opacity-30 saturate-50',
  none: '',
};

export default function CourseCard({
  course,
  highlight,
  prereqNames,
  onHover,
  onClick,
  registerRef,
  colors,
}: CourseCardProps) {
  const tagMeta = TAG_META[course.tag];
  const isRecommended = course.tag === 'recommended';
  const tooltipText = prereqNames.length > 0
    ? `建議先修：${prereqNames.join('、')}`
    : '無建議先修';

  const cardBg = isRecommended ? 'bg-slate-100' : colors.card;
  const cardBorder = isRecommended ? 'border-slate-300' : colors.border;
  const accentColor = isRecommended ? 'text-slate-500' : colors.accent;

  return (
    <div
      ref={(el) => registerRef(course.id, el)}
      onMouseEnter={() => onHover(course.id)}
      onMouseLeave={() => onHover(null)}
      onClick={() => onClick(course.id)}
      title={tooltipText}
      className={`group relative cursor-pointer rounded-xl border ${cardBg} ${cardBorder} p-2.5 transition-all duration-300 ease-out ${HIGHLIGHT_STYLES[highlight]} hover:shadow-md`}
    >
      <div className="mb-1 flex items-center justify-between">
        <span className={`text-[10px] font-bold ${accentColor}`}>
          {course.credits} 學分
        </span>
        <span className={`rounded border px-1.5 py-0.5 text-[10px] font-semibold ${tagMeta.className}`}>
          {tagMeta.label}
        </span>
      </div>
      <div className="flex items-start gap-1.5">
        <GraduationCap className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${accentColor}`} />
        <p className="text-xs font-semibold leading-snug text-slate-700">
          {course.name}
        </p>
      </div>
      {course.prereqs.length > 0 && (
        <div className="mt-1.5 flex items-center gap-1 border-t border-slate-200/60 pt-1.5">
          <span className="text-[9px] text-slate-400">建議先修:</span>
          <span className="text-[9px] font-medium text-slate-500">
            {course.prereqs.length} 門
          </span>
        </div>
      )}
    </div>
  );
}

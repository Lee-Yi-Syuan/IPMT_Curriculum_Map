import { useRef, useState, useLayoutEffect, useCallback } from 'react';
import { ArrowRight } from 'lucide-react';
import {
  SEMESTERS,
  getSpecialtyColors,
  type Course,
} from '../curriculum/data';
import CourseCard, { type HighlightState } from './CourseCard';

interface CurriculumGridProps {
  courses: Course[];
  activeId: string | null;
  hoverId: string | null;
  onHover: (id: string | null) => void;
  onClick: (id: string) => void;
  specialtyKeys: string[];
}

function getRelatedSet(courses: Course[], activeId: string) {
  const prereqs = new Set<string>();
  const dependents = new Set<string>();
  const courseMap = new Map(courses.map((c) => [c.id, c]));

  const active = courseMap.get(activeId);
  if (active) {
    active.prereqs.forEach((p) => {
      if (courseMap.has(p)) prereqs.add(p);
    });
  }
  courses.forEach((c) => {
    if (c.prereqs.includes(activeId)) dependents.add(c.id);
  });
  return { prereqs, dependents };
}

export default function CurriculumGrid({
  courses,
  activeId,
  hoverId,
  onHover,
  onClick,
  specialtyKeys,
}: CurriculumGridProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const [containerRect, setContainerRect] = useState<{ w: number; h: number }>({ w: 0, h: 0 });
  const [edgePositions, setEdgePositions] = useState<
    { id: string; x1: number; y1: number; x2: number; y2: number; type: 'prereq' | 'dependent' }[]
  >([]);

  const colorsMap = getSpecialtyColors(specialtyKeys);

  const registerRef = useCallback((id: string, el: HTMLDivElement | null) => {
    if (el) cardRefs.current.set(id, el);
    else cardRefs.current.delete(id);
  }, []);

  const focusId = activeId ?? hoverId;

  const computeEdges = useCallback(() => {
    const container = containerRef.current;
    if (!container || !focusId) {
      setEdgePositions([]);
      return;
    }
    const cRect = container.getBoundingClientRect();
    setContainerRect({ w: cRect.width, h: cRect.height });

    const { prereqs, dependents } = getRelatedSet(courses, focusId);
    const edges: typeof edgePositions = [];

    prereqs.forEach((pid) => {
      const fromEl = cardRefs.current.get(pid);
      const toEl = cardRefs.current.get(focusId);
      if (fromEl && toEl) {
        const f = fromEl.getBoundingClientRect();
        const t = toEl.getBoundingClientRect();
        edges.push({
          id: `${pid}->${focusId}`,
          x1: f.left - cRect.left + f.width / 2,
          y1: f.top - cRect.top + f.height / 2,
          x2: t.left - cRect.left + t.width / 2,
          y2: t.top - cRect.top + t.height / 2,
          type: 'prereq',
        });
      }
    });

    dependents.forEach((did) => {
      const fromEl = cardRefs.current.get(focusId);
      const toEl = cardRefs.current.get(did);
      if (fromEl && toEl) {
        const f = fromEl.getBoundingClientRect();
        const t = toEl.getBoundingClientRect();
        edges.push({
          id: `${focusId}->${did}`,
          x1: f.left - cRect.left + f.width / 2,
          y1: f.top - cRect.top + f.height / 2,
          x2: t.left - cRect.left + t.width / 2,
          y2: t.top - cRect.top + t.height / 2,
          type: 'dependent',
        });
      }
    });

    setEdgePositions(edges);
  }, [focusId, courses]);

  useLayoutEffect(() => {
    computeEdges();
    const handleResize = () => computeEdges();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [computeEdges]);

  const getHighlight = useCallback(
    (course: Course): HighlightState => {
      if (!focusId) return 'none';
      if (course.id === focusId) return 'active';
      const { prereqs, dependents } = getRelatedSet(courses, focusId);
      if (prereqs.has(course.id)) return 'prereq';
      if (dependents.has(course.id)) return 'dependent';
      return 'dim';
    },
    [focusId, courses]
  );

  const getPrereqNames = useCallback(
    (course: Course): string[] => {
      return course.prereqs
        .map((pid) => courses.find((c) => c.id === pid)?.name)
        .filter((n): n is string => n !== undefined);
    },
    [courses]
  );

  const coursesBySemester = SEMESTERS.map((sem) => ({
    sem,
    items: courses.filter((c) => c.semester === sem.id),
  }));

  return (
    <div className="relative overflow-x-auto">
      <div ref={containerRef} className="relative min-w-[1100px]">
        {/* SVG arrow overlay - 建議修課指引線 */}
        <svg
          className="pointer-events-none absolute inset-0 z-30"
          width={containerRect.w}
          height={containerRect.h}
          style={{ overflow: 'visible' }}
        >
          <defs>
            <marker
              id="arrow-prereq"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#10b981" />
            </marker>
            <marker
              id="arrow-dependent"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#8b5cf6" />
            </marker>
          </defs>
          {edgePositions.map((e) => (
            <g key={e.id}>
              <line
                x1={e.x1}
                y1={e.y1}
                x2={e.x2}
                y2={e.y2}
                stroke={e.type === 'prereq' ? '#10b981' : '#8b5cf6'}
                strokeWidth="2"
                strokeDasharray="6 4"
                markerEnd={e.type === 'prereq' ? 'url(#arrow-prereq)' : 'url(#arrow-dependent)'}
                className="animate-[dashFlow_1s_linear_infinite]"
                opacity="0.85"
              />
            </g>
          ))}
        </svg>

        {/* Semester columns */}
        <div className="grid grid-cols-8 gap-3 px-2 pb-4">
          {coursesBySemester.map(({ sem, items }) => (
            <div key={sem.id} className="flex flex-col gap-2">
              <div className="sticky top-0 z-10 mb-1 rounded-lg bg-slate-100 py-2 text-center">
                <p className="text-xs font-bold text-slate-600">{sem.label}</p>
                <p className="text-[10px] text-slate-400">{items.length} 門</p>
              </div>
              <div className="flex flex-col gap-2">
                {items.map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    highlight={getHighlight(course)}
                    prereqNames={getPrereqNames(course)}
                    onHover={onHover}
                    onClick={onClick}
                    registerRef={registerRef}
                    colors={colorsMap[course.specialtyKey] ?? { card: 'bg-slate-50', border: 'border-slate-300', glow: 'shadow-slate-400/50', accent: 'text-slate-700' }}
                  />
                ))}
                {items.length === 0 && (
                  <div className="rounded-lg border border-dashed border-slate-200 py-6 text-center">
                    <span className="text-[10px] text-slate-300">—</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="mt-2 flex flex-wrap items-center gap-4 border-t border-slate-100 px-4 py-3">
        <span className="text-xs font-semibold text-slate-500">圖例:</span>
        <div className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded ring-2 ring-slate-900" />
          <span className="text-xs text-slate-600">選取課程</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded ring-2 ring-emerald-500" />
          <span className="text-xs text-slate-600">建議先修課程</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded ring-2 ring-violet-500" />
          <span className="text-xs text-slate-600">後續課程</span>
        </div>
        <div className="ml-auto flex items-center gap-1 text-[11px] text-slate-400">
          <ArrowRight className="h-3 w-3" />
          建議修課指引線 — 懸停或點擊課程查看建議先修關係
        </div>
      </div>
    </div>
  );
}

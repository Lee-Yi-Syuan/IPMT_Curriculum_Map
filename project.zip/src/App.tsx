import { useState, useMemo, useCallback } from 'react';
import Navbar from './components/Navbar';
import CurriculumGrid from './components/CurriculumGrid';
import Sidebar from './components/Sidebar';
import {
  getCoursesForSpecialties,
  getSpecialtyByKey,
  DEFAULT_FIRST,
  DEFAULT_SECOND,
} from './curriculum/data';

const TAG_ORDER: Record<string, number> = { required: 0, elective: 1, recommended: 2 };

export default function App() {
  const [specOne, setSpecOne] = useState<string>(DEFAULT_FIRST);
  const [specTwo, setSpecTwo] = useState<string>(DEFAULT_SECOND);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [hoverId, setHoverId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const specialtyKeys = useMemo(() => [specOne, specTwo], [specOne, specTwo]);

  const courses = useMemo(
    () => getCoursesForSpecialties(specialtyKeys),
    [specialtyKeys]
  );

  const sortedCourses = useMemo(() => {
    return [...courses].sort((a, b) => {
      if (a.specialtyKey !== b.specialtyKey) {
        return a.specialtyKey === specOne ? -1 : 1;
      }
      return TAG_ORDER[a.tag] - TAG_ORDER[b.tag];
    });
  }, [courses, specOne]);

  const activeCourse = useMemo(
    () => courses.find((c) => c.id === (activeId ?? hoverId)) ?? null,
    [courses, activeId, hoverId]
  );

  const handleSpecOneChange = useCallback((key: string) => {
    setSpecOne(key);
    setActiveId(null);
    setHoverId(null);
  }, []);

  const handleSpecTwoChange = useCallback((key: string) => {
    setSpecTwo(key);
    setActiveId(null);
    setHoverId(null);
  }, []);

  const handleGenerate = useCallback(() => {
    setIsGenerating(true);
    setActiveId(null);
    setHoverId(null);
    setTimeout(() => setIsGenerating(false), 400);
  }, []);

  const handleClick = useCallback((id: string) => {
    setActiveId((prev) => (prev === id ? null : id));
  }, []);

  const specOneInfo = getSpecialtyByKey(specOne);
  const specTwoInfo = getSpecialtyByKey(specTwo);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar
        specOne={specOne}
        specTwo={specTwo}
        onSpecOneChange={handleSpecOneChange}
        onSpecTwoChange={handleSpecTwoChange}
        onGenerate={handleGenerate}
      />

      <main className="mx-auto max-w-[1600px] px-6 py-6">
        {/* Combination banner */}
        <div className="mb-5 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-sm ring-1 ring-slate-200">
            <span className="h-2.5 w-2.5 rounded-full bg-blue-500" />
            <span className="text-sm font-semibold text-slate-700">{specOneInfo?.name ?? ''}</span>
            <span className="text-[10px] text-slate-400">({specOneInfo?.typeName})</span>
          </div>
          <span className="text-lg font-light text-slate-300">+</span>
          <div className="flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-sm ring-1 ring-slate-200">
            <span className="h-2.5 w-2.5 rounded-full bg-orange-500" />
            <span className="text-sm font-semibold text-slate-700">{specTwoInfo?.name ?? ''}</span>
            <span className="text-[10px] text-slate-400">({specTwoInfo?.typeName})</span>
          </div>
          <span className="ml-1 text-sm text-slate-400">
            共 {courses.length} 門課程
          </span>
        </div>

        <div className="flex flex-col gap-5 lg:flex-row">
          <div
            className={`flex-1 transition-opacity duration-300 ${isGenerating ? 'opacity-30' : 'opacity-100'}`}
          >
            <CurriculumGrid
              courses={sortedCourses}
              activeId={activeId}
              hoverId={hoverId}
              onHover={setHoverId}
              onClick={handleClick}
              specialtyKeys={specialtyKeys}
            />
          </div>
          <Sidebar
            courses={courses}
            specOneKey={specOne}
            specTwoKey={specTwo}
            activeCourse={activeCourse}
          />
        </div>
      </main>
    </div>
  );
}
